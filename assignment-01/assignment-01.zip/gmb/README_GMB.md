### To-do list: 

- Main menu:
    - potentiometer difficulty factor (1-4)
    - Ls LED pulsing
- Deep sleep (10s) + interrupts wake up
- Game start
- Game logic:
    - Random generation
    - Buttons and LEDs
    - Game time
- End game:
    - Check the guess
    - Update score
    - Difficulty factor on game time (decide values and step)

### Displaying on LCD:
- Welcome message
- Print difficulty?
- Go!
- Number to guess (time left?)
- "Good: score" OR "Game Over: score"