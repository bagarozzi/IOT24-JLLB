package it.unibo.api;


public interface Connection {

    void sendCommand(String command);

}
