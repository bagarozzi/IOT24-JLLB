#ifndef __CONFIG__
#define __CONFIG__

#define POT_PIN A0
#define BT_PIN 3
#define MOTOR_PIN 9

#endif